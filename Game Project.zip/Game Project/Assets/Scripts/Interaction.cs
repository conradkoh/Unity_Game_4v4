﻿using UnityEngine;
using System.Collections;

public interface IInteraction{
	void Interact();
}
